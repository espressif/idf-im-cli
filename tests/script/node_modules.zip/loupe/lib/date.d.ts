import type { Options } from './types.js';
export default function inspectDate(dateObject: Date, options: Options): string;
//# sourceMappingURL=date.d.ts.map
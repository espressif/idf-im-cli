import type { Options } from './types.js';
export default function inspectRegExp(value: RegExp, options: Options): string;
//# sourceMappingURL=regexp.d.ts.map
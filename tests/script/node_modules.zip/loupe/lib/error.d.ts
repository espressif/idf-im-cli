import type { Options } from './types.js';
export default function inspectObject(error: Error, options: Options): string;
//# sourceMappingURL=error.d.ts.map
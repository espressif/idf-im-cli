import type { Options } from './types.js';
type GetPromiseValue = (value: Promise<unknown>, options: Options) => string;
declare let getPromiseValue: GetPromiseValue;
export default getPromiseValue;
//# sourceMappingURL=promise.d.ts.map
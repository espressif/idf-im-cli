import type { Options } from './types.js';
export default function inspectArray(array: ArrayLike<unknown>, options: Options): string;
//# sourceMappingURL=array.d.ts.map
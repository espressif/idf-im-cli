import type { Options } from './types.js';
type TypedArray = Int8Array | Uint8Array | Uint8ClampedArray | Int16Array | Uint16Array | Int32Array | Uint32Array | Float32Array | Float64Array;
export default function inspectTypedArray(array: TypedArray, options: Options): string;
export {};
//# sourceMappingURL=typedarray.d.ts.map
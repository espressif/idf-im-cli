const {assert} = require('./chai.cjs');

globalThis.assert = assert;

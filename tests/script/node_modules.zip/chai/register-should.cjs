const {should} = require('./chai.cjs');

globalThis.should = should();

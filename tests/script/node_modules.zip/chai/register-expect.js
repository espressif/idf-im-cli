import {expect} from './index.js';

globalThis.expect = expect;
